# WallopSlider

This branch contains the most basic set up of WallopSlider for a workshop.

I converted the Sass files to CSS so it's easier to explain how to build custom animations.
